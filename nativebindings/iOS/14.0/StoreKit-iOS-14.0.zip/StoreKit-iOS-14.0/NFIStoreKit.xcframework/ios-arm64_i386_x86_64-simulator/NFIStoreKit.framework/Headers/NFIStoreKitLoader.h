#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIStoreKitModules(JSContext* context);
JSValue* extractNFIStoreKitStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIStoreKitStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);

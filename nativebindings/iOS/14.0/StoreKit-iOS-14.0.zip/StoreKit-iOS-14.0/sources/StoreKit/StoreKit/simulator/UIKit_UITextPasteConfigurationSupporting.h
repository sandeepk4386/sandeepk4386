#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UITextPasteConfigurationSupporting_symbols(JSContext*);
@protocol UITextPasteConfigurationSupportingInstanceExports_<JSExport, UIPasteConfigurationSupportingInstanceExports_>
@property (nonatomic,weak) id pasteDelegate;
@end
@protocol UITextPasteConfigurationSupportingClassExports_<JSExport, UIPasteConfigurationSupportingClassExports_>
@end
#pragma clang diagnostic pop
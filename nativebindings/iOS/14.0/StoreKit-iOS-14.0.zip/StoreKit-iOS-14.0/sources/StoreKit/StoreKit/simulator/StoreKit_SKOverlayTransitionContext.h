#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKOverlayTransitionContext_symbols(JSContext*);
@protocol SKOverlayTransitionContextInstanceExports<JSExport>
@property (readonly,nonatomic) CGRect startFrame;
@property (readonly,nonatomic) CGRect endFrame;
JSExportAs(addAnimationBlock,
-(void) jsaddAnimationBlock: (JSValue *) block );
@end
@protocol SKOverlayTransitionContextClassExports<JSExport>
@end
#pragma clang diagnostic pop
#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKCloudServiceSetupViewController_symbols(JSContext*);
@protocol SKCloudServiceSetupViewControllerInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
JSExportAs(loadWithOptionsCompletionHandler,
-(void) jsloadWithOptions: (NSDictionary *) options completionHandler: (JSValue *) completionHandler );
@end
@protocol SKCloudServiceSetupViewControllerClassExports<JSExport>
@end
@protocol SKCloudServiceSetupViewControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) cloudServiceSetupViewControllerDidDismiss: (SKCloudServiceSetupViewController *) cloudServiceSetupViewController ;
@end
@protocol SKCloudServiceSetupViewControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop
#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKAdNetwork_symbols(JSContext*);
@protocol SKAdNetworkInstanceExports<JSExport>
@end
@protocol SKAdNetworkClassExports<JSExport>
+(void) updateConversionValue: (NSInteger) conversionValue ;
+(void) registerAppForAdNetworkAttribution;
@end
#pragma clang diagnostic pop
#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation SKCloudServiceController (Exports)
-(void) jsrequestCapabilitiesWithCompletionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(SKCloudServiceCapability, NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(SKCloudServiceCapability arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self requestCapabilitiesWithCompletionHandler: completionHandler_ ];
}
-(void) jsrequestUserTokenForDeveloperToken: (NSString *) developerToken completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSString * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSString * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self requestUserTokenForDeveloperToken: developerToken completionHandler: completionHandler_ ];
}
-(void) jsrequestPersonalizationTokenForClientToken: (NSString *) clientToken withCompletionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSString * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSString * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self requestPersonalizationTokenForClientToken: clientToken withCompletionHandler: completionHandler_ ];
}
-(void) jsrequestStorefrontCountryCodeWithCompletionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSString * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSString * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self requestStorefrontCountryCodeWithCompletionHandler: completionHandler_ ];
}
-(void) jsrequestStorefrontIdentifierWithCompletionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSString * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSString * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	[self requestStorefrontIdentifierWithCompletionHandler: completionHandler_ ];
}
+(void) jsrequestAuthorization: (JSValue *) handler 
{
	void (^ handler_)(SKCloudServiceAuthorizationStatus) = nil;
	if (!handler.isUndefined) {
		handler_ = ^void(SKCloudServiceAuthorizationStatus arg0) {
			JSContext* __jsContext = handler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			callJSFunction(__jsContext, handler, self, parameters);
		};
	}
	[self requestAuthorization: handler_ ];
}
@end
static void addProtocols()
{
	class_addProtocol([SKCloudServiceController class], @protocol(SKCloudServiceControllerInstanceExports));
	class_addProtocol([SKCloudServiceController class], @protocol(SKCloudServiceControllerClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"SKCloudServiceAuthorizationStatusNotDetermined"] = @0L;
	context[@"SKCloudServiceAuthorizationStatusDenied"] = @1L;
	context[@"SKCloudServiceAuthorizationStatusRestricted"] = @2L;
	context[@"SKCloudServiceAuthorizationStatusAuthorized"] = @3L;

	context[@"SKCloudServiceCapabilityNone"] = @0UL;
	context[@"SKCloudServiceCapabilityMusicCatalogPlayback"] = @1UL;
	context[@"SKCloudServiceCapabilityMusicCatalogSubscriptionEligible"] = @2UL;
	context[@"SKCloudServiceCapabilityAddToCloudMusicLibrary"] = @256UL;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &SKCloudServiceCapabilitiesDidChangeNotification;
	if (p != NULL) context[@"SKCloudServiceCapabilitiesDidChangeNotification"] = SKCloudServiceCapabilitiesDidChangeNotification;
	p = (void*) &SKStorefrontIdentifierDidChangeNotification;
	if (p != NULL) context[@"SKStorefrontIdentifierDidChangeNotification"] = SKStorefrontIdentifierDidChangeNotification;
	p = (void*) &SKStorefrontCountryCodeDidChangeNotification;
	if (p != NULL) context[@"SKStorefrontCountryCodeDidChangeNotification"] = SKStorefrontCountryCodeDidChangeNotification;
}
void load_StoreKit_SKCloudServiceController_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

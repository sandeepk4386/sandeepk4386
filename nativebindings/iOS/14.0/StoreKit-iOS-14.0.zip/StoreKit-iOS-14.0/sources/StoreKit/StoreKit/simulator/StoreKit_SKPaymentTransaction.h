#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKPaymentTransaction_symbols(JSContext*);
@protocol SKPaymentTransactionInstanceExports<JSExport>
@property (readonly,nonatomic) NSData * transactionReceipt;
@property (readonly,nonatomic) SKPaymentTransaction * originalTransaction;
@property (readonly,nonatomic) NSArray * downloads;
@property (readonly,nonatomic) NSDate * transactionDate;
@property (readonly,nonatomic) NSString * transactionIdentifier;
@property (readonly,nonatomic) NSError * error;
@property (readonly,nonatomic) SKPayment * payment;
@property (readonly,nonatomic) SKPaymentTransactionState transactionState;
@end
@protocol SKPaymentTransactionClassExports<JSExport>
@end
#pragma clang diagnostic pop
#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UIVibrancyEffect_symbols(JSContext*);
@protocol UIVibrancyEffectInstanceExports<JSExport>
@end
@protocol UIVibrancyEffectClassExports<JSExport>
+(UIVibrancyEffect *) effectForBlurEffect: (UIBlurEffect *) blurEffect ;
@end
@protocol UIVibrancyEffectAdditionalStylesCategoryInstanceExports<JSExport>
@end
@protocol UIVibrancyEffectAdditionalStylesCategoryClassExports<JSExport>
+(UIVibrancyEffect *) effectForBlurEffect: (UIBlurEffect *) blurEffect style: (UIVibrancyEffectStyle) style ;
@end
#pragma clang diagnostic pop
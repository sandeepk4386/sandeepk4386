#import "allincludes.h"
#import <JavaScriptCore/JavaScriptCore.h>
void loadNFIStoreKitModules(JSContext* context)
{
	load_StoreKit_SKProductStorePromotionController_symbols(context);
	load_StoreKit_SKDownload_symbols(context);
	load_StoreKit_SKPaymentDiscount_symbols(context);
	load_StoreKit_SKPaymentTransaction_symbols(context);
	load_StoreKit_SKStorefront_symbols(context);
	load_StoreKit_SKCloudServiceController_symbols(context);
	load_StoreKit_SKOverlayTransitionContext_symbols(context);
	load_StoreKit_SKProductsRequest_symbols(context);
	load_StoreKit_SKRequest_symbols(context);
	load_StoreKit_SKAdNetwork_symbols(context);
	load_StoreKit_SKCloudServiceSetupViewController_symbols(context);
	load_StoreKit_SKOverlay_symbols(context);
	load_StoreKit_SKStoreReviewController_symbols(context);
	load_StoreKit_SKProduct_symbols(context);
	load_StoreKit_SKPaymentQueue_symbols(context);
	load_StoreKit_SKReceiptRefreshRequest_symbols(context);
	load_StoreKit_SKOverlayConfiguration_symbols(context);
	load_StoreKit_SKProductDiscount_symbols(context);
	load_StoreKit_SKPayment_symbols(context);
	load_StoreKit_SKError_symbols(context);
	load_StoreKit_SKArcadeService_symbols(context);
	load_StoreKit_SKStoreProductViewController_symbols(context);
}

JSValue* extractNFIStoreKitStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context)
{
    
    return nil;
}

BOOL setNFIStoreKitStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation)
{
    
    return NO;
}


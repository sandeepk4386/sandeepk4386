#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKProductsRequest_symbols(JSContext*);
@protocol SKProductsResponseInstanceExports<JSExport>
@property (readonly,nonatomic) NSArray * invalidProductIdentifiers;
@property (readonly,nonatomic) NSArray * products;
@end
@protocol SKProductsResponseClassExports<JSExport>
@end
@protocol SKProductsRequestInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
JSExportAs(initWithProductIdentifiers,
-(id) jsinitWithProductIdentifiers: (NSSet *) productIdentifiers );
@end
@protocol SKProductsRequestClassExports<JSExport>
@end
@protocol SKProductsRequestDelegateInstanceExports_<JSExport, SKRequestDelegateInstanceExports_>
-(void) productsRequest: (SKProductsRequest *) request didReceiveResponse: (SKProductsResponse *) response ;
@end
@protocol SKProductsRequestDelegateClassExports_<JSExport, SKRequestDelegateClassExports_>
@end
#pragma clang diagnostic pop
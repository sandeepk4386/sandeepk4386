#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKProduct_symbols(JSContext*);
@protocol SKProductSubscriptionPeriodInstanceExports<JSExport>
@property (readonly,nonatomic) NSUInteger numberOfUnits;
@property (readonly,nonatomic) SKProductPeriodUnit unit;
@end
@protocol SKProductSubscriptionPeriodClassExports<JSExport>
@end
@protocol SKProductInstanceExports<JSExport>
@property (readonly,nonatomic) NSArray * downloadContentLengths;
@property (readonly,nonatomic) SKProductDiscount * introductoryPrice;
@property (readonly,nonatomic) SKProductSubscriptionPeriod * subscriptionPeriod;
@property (readonly,nonatomic) BOOL isFamilyShareable;
@property (readonly,nonatomic) NSString * localizedDescription;
@property (readonly,nonatomic) NSDecimalNumber * price;
@property (readonly,nonatomic) NSString * productIdentifier;
@property (readonly,nonatomic) NSString * localizedTitle;
@property (readonly,nonatomic) NSArray * discounts;
@property (readonly,nonatomic) NSString * contentVersion;
@property (readonly,nonatomic) NSLocale * priceLocale;
@property (readonly,nonatomic) NSString * downloadContentVersion;
@property (readonly,nonatomic) NSString * subscriptionGroupIdentifier;
@property (readonly,nonatomic) BOOL isDownloadable;
@end
@protocol SKProductClassExports<JSExport>
@end
#pragma clang diagnostic pop
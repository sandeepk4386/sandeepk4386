#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKStoreReviewController_symbols(JSContext*);
@protocol SKStoreReviewControllerInstanceExports<JSExport>
@end
@protocol SKStoreReviewControllerClassExports<JSExport>
+(void) requestReviewInScene: (UIWindowScene *) windowScene ;
+(void) requestReview;
@end
#pragma clang diagnostic pop
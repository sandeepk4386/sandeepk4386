#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKPaymentQueue_symbols(JSContext*);
@protocol SKPaymentQueueInstanceExports<JSExport>
@property (readonly,nonatomic) NSArray * transactions;
@property (nonatomic,weak) id delegate;
@property (readonly,nonatomic) SKStorefront * storefront;
@property (readonly,nonatomic) NSArray * transactionObservers;
-(void) cancelDownloads: (NSArray *) downloads ;
-(void) addPayment: (SKPayment *) payment ;
-(void) restoreCompletedTransactions;
-(void) presentCodeRedemptionSheet;
-(void) finishTransaction: (SKPaymentTransaction *) transaction ;
-(void) removeTransactionObserver: (id) observer ;
-(void) showPriceConsentIfNeeded;
-(void) restoreCompletedTransactionsWithApplicationUsername: (NSString *) username ;
-(void) startDownloads: (NSArray *) downloads ;
-(void) resumeDownloads: (NSArray *) downloads ;
-(void) pauseDownloads: (NSArray *) downloads ;
-(void) addTransactionObserver: (id) observer ;
@end
@protocol SKPaymentQueueClassExports<JSExport>
+(BOOL) canMakePayments;
+(id) defaultQueue;
@end
@protocol SKPaymentTransactionObserverInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) paymentQueue: (SKPaymentQueue *) queue restoreCompletedTransactionsFailedWithError: (NSError *) error ;
-(void) paymentQueue: (SKPaymentQueue *) queue removedTransactions: (NSArray *) transactions ;
-(void) paymentQueue: (SKPaymentQueue *) queue updatedDownloads: (NSArray *) downloads ;
-(void) paymentQueueDidChangeStorefront: (SKPaymentQueue *) queue ;
-(void) paymentQueueRestoreCompletedTransactionsFinished: (SKPaymentQueue *) queue ;
-(void) paymentQueue: (SKPaymentQueue *) queue didRevokeEntitlementsForProductIdentifiers: (NSArray *) productIdentifiers ;
-(void) paymentQueue: (SKPaymentQueue *) queue updatedTransactions: (NSArray *) transactions ;
-(BOOL) paymentQueue: (SKPaymentQueue *) queue shouldAddStorePayment: (SKPayment *) payment forProduct: (SKProduct *) product ;
@end
@protocol SKPaymentTransactionObserverClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol SKPaymentQueueDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(BOOL) paymentQueue: (SKPaymentQueue *) paymentQueue shouldContinueTransaction: (SKPaymentTransaction *) transaction inStorefront: (SKStorefront *) newStorefront ;
-(BOOL) paymentQueueShouldShowPriceConsent: (SKPaymentQueue *) paymentQueue ;
@end
@protocol SKPaymentQueueDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop
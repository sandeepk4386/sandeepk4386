#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKOverlayConfiguration_symbols(JSContext*);
@protocol SKOverlayConfigurationInstanceExports<JSExport>
@end
@protocol SKOverlayConfigurationClassExports<JSExport>
@end
@protocol SKOverlayAppClipConfigurationInstanceExports<JSExport>
@property (retain,nonatomic) NSString * campaignToken;
@property (nonatomic) SKOverlayPosition position;
@property (retain,nonatomic) NSString * providerToken;
JSExportAs(initWithPosition,
-(id) jsinitWithPosition: (SKOverlayPosition) position );
-(void) setAdditionalValue: (id) value forKey: (NSString *) key ;
-(id) additionalValueForKey: (NSString *) key ;
@end
@protocol SKOverlayAppClipConfigurationClassExports<JSExport>
@end
@protocol SKOverlayAppConfigurationInstanceExports<JSExport>
@property (retain,nonatomic) NSString * campaignToken;
@property (nonatomic) SKOverlayPosition position;
@property (retain,nonatomic) NSString * providerToken;
@property (nonatomic) BOOL userDismissible;
@property (retain,nonatomic) NSString * appIdentifier;
-(void) setAdditionalValue: (id) value forKey: (NSString *) key ;
-(id) additionalValueForKey: (NSString *) key ;
JSExportAs(initWithAppIdentifierPosition,
-(id) jsinitWithAppIdentifier: (NSString *) appIdentifier position: (SKOverlayPosition) position );
@end
@protocol SKOverlayAppConfigurationClassExports<JSExport>
@end
#pragma clang diagnostic pop
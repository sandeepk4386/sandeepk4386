#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKStoreProductViewController_symbols(JSContext*);
@protocol SKStoreProductViewControllerInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
JSExportAs(loadProductWithParametersCompletionBlock,
-(void) jsloadProductWithParameters: (NSDictionary *) parameters completionBlock: (JSValue *) block );
@end
@protocol SKStoreProductViewControllerClassExports<JSExport>
@end
@protocol SKStoreProductViewControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) productViewControllerDidFinish: (SKStoreProductViewController *) viewController ;
@end
@protocol SKStoreProductViewControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop
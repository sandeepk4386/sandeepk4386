#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKDownload_symbols(JSContext*);
@protocol SKDownloadInstanceExports<JSExport>
@property (readonly,nonatomic) NSURL * contentURL;
@property (readonly,nonatomic) NSTimeInterval timeRemaining;
@property (readonly,nonatomic) long long expectedContentLength;
@property (readonly,nonatomic) SKPaymentTransaction * transaction;
@property (readonly,nonatomic) SKDownloadState downloadState;
@property (readonly,nonatomic) SKDownloadState state;
@property (readonly,nonatomic) NSString * contentVersion;
@property (readonly,nonatomic) NSError * error;
@property (readonly,nonatomic) float progress;
@property (readonly,nonatomic) NSString * contentIdentifier;
@property (readonly,nonatomic) long long contentLength;
@end
@protocol SKDownloadClassExports<JSExport>
@end
#pragma clang diagnostic pop
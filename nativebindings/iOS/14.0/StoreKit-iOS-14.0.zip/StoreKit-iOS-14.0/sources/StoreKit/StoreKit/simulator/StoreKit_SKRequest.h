#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_StoreKit_SKRequest_symbols(JSContext*);
@protocol SKRequestInstanceExports<JSExport>
@property (nonatomic,weak) id delegate;
-(void) cancel;
-(void) start;
@end
@protocol SKRequestClassExports<JSExport>
@end
@protocol SKRequestDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) request: (SKRequest *) request didFailWithError: (NSError *) error ;
-(void) requestDidFinish: (SKRequest *) request ;
@end
@protocol SKRequestDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop
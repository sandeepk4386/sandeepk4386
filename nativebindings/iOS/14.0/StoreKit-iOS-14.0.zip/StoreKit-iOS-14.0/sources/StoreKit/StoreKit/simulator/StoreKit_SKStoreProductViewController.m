#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation SKStoreProductViewController (Exports)
-(void) jsloadProductWithParameters: (NSDictionary *) parameters completionBlock: (JSValue *) block 
{
	void (^ block_)(BOOL, NSError * ) = nil;
	if (!block.isUndefined) {
		block_ = ^void(BOOL arg0, NSError * arg1) {
			JSContext* __jsContext = block.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: [JSValue valueWithObject: @(arg0) inContext: __jsContext]];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, block, self, parameters);
		};
	}
	[self loadProductWithParameters: parameters completionBlock: block_ ];
}
@end
static void addProtocols()
{
	class_addProtocol([SKStoreProductViewController class], @protocol(SKStoreProductViewControllerInstanceExports));
	class_addProtocol([SKStoreProductViewController class], @protocol(SKStoreProductViewControllerClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &SKStoreProductParameterAdvertisingPartnerToken;
	if (p != NULL) context[@"SKStoreProductParameterAdvertisingPartnerToken"] = SKStoreProductParameterAdvertisingPartnerToken;
	p = (void*) &SKStoreProductParameterAffiliateToken;
	if (p != NULL) context[@"SKStoreProductParameterAffiliateToken"] = SKStoreProductParameterAffiliateToken;
	p = (void*) &SKStoreProductParameterITunesItemIdentifier;
	if (p != NULL) context[@"SKStoreProductParameterITunesItemIdentifier"] = SKStoreProductParameterITunesItemIdentifier;
	p = (void*) &SKStoreProductParameterProductIdentifier;
	if (p != NULL) context[@"SKStoreProductParameterProductIdentifier"] = SKStoreProductParameterProductIdentifier;
	p = (void*) &SKStoreProductParameterProviderToken;
	if (p != NULL) context[@"SKStoreProductParameterProviderToken"] = SKStoreProductParameterProviderToken;
	p = (void*) &SKStoreProductParameterCampaignToken;
	if (p != NULL) context[@"SKStoreProductParameterCampaignToken"] = SKStoreProductParameterCampaignToken;
}
void StoreKit_SKStoreProductViewControllerProtocols()
{
	(void)@protocol(SKStoreProductViewControllerDelegate);
}
void load_StoreKit_SKStoreProductViewController_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop

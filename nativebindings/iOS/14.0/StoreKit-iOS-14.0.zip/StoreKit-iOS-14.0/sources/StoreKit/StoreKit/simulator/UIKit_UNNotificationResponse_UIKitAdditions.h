#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UNNotificationResponse_UIKitAdditions_symbols(JSContext*);
@protocol UNNotificationResponseUIKitAdditionsCategoryInstanceExports<JSExport>
@property (readonly,nonatomic) UIScene * targetScene;
@end
@protocol UNNotificationResponseUIKitAdditionsCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop
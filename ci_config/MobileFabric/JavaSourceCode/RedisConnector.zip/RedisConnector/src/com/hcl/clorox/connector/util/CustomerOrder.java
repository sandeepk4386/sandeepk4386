package com.hcl.clorox.connector.util;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Record;

@SuppressWarnings("rawtypes")
public class CustomerOrder implements Comparator {
	public static final List<String> customerDefinedOrder = Arrays.asList("Walmart", "Costco", "Sams", "Target",
			"Amazon", "Kroger", "Dollar Gen", "BJs", "Dollar Tree", "Home Depot", "All Others");

	@Override
	public int compare(Object r1, Object r2) {

		Map<String, Param> parameterMap1 = fillMap((List<Param>) ((Record) r1).getAllParams());
		Map<String, Param> parameterMap2 = fillMap((List<Param>) ((Record) r2).getAllParams());

		if (parameterMap1.get("name") != null && parameterMap2.get("name") != null) {
			Integer o1Index = customerDefinedOrder.indexOf(parameterMap1.get("name").getValue().trim());
			Integer o2Index = customerDefinedOrder.indexOf(parameterMap2.get("name").getValue().trim());
			return o1Index.compareTo(o2Index);

		}
		return 0;
	}

	public static HashMap<String, Param> fillMap(List<Param> xPathParams) {
		HashMap<String, Param> map = new HashMap<String, Param>();
		for (Param param : xPathParams) {
			map.put(param.getName(), param);
		}
		return map;
	}

}

package com.hcl.clorox.connector;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.apache.log4j.Logger;

import com.google.gson.JsonParser;
import com.hcl.clorox.connector.util.CloroxUtil;
import com.hcl.clorox.connector.util.CustomerOrder;
import com.konylabs.middleware.common.DataPreProcessor2;
import com.konylabs.middleware.controller.DataControllerRequest;
import com.konylabs.middleware.controller.DataControllerResponse;
import com.konylabs.middleware.dataobject.Dataset;
import com.konylabs.middleware.dataobject.JSONToResult;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Record;
import com.konylabs.middleware.dataobject.Result;

import io.lettuce.core.RedisClient;
import io.lettuce.core.RedisURI;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;
import io.lettuce.core.support.ConnectionPoolSupport;

public class RedisConnectorProcessor implements DataPreProcessor2 {
	public static final Logger LOG = Logger.getLogger(RedisConnectorProcessor.class);
	private static RedisClient redisClient = null;

	private static String host = CloroxUtil.getServerConfigurableParameter("REDIS_HOST");
	private static char[] pass = CloroxUtil.getServerConfigurableParameter("REDIS_PASS").toCharArray();
	private static int port = CloroxUtil.getServerConfigurableNumericParameter("REDIS_PORT");

	public static void setredisClient(RedisClient client) {
		redisClient = client;
	}

	public static RedisClient getHttpClient() {

		if (redisClient == null)
			redisClient = RedisClient
					.create(RedisURI.Builder.redis(host, port).withSsl(true).withPassword(pass).build());
		return redisClient;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public boolean execute(HashMap inputMap, DataControllerRequest request, DataControllerResponse arg2, Result result)
			throws Exception {
		LOG.debug("executing RedisConnectorProcessor ----");

		if (RedisConnectorProcessor.getHttpClient() != null) {
			GenericObjectPool<StatefulRedisConnection<String, String>> pool = ConnectionPoolSupport
					.createGenericObjectPool(() -> redisClient.connect(), new GenericObjectPoolConfig());

			// Get connection from pool
			try (StatefulRedisConnection<String, String> connection = pool.borrowObject()) {
				RedisCommands<String, String> commands = connection.sync();

				String query = "";

				if (inputMap.containsKey("query")) {
					query = (String) inputMap.get("query");
				}

				String command_response = commands.get(query);
				Result customResult = new Result();

				if (command_response != null) {
					JsonParser js = new JsonParser();
					if (command_response.contains("'Common'")) {
						// Raw Data received from REDIS will have single quote. Change it double quote
						command_response = command_response.replaceAll("'", "\"");

						// some fields retunr None object , convert None to String "None"
						command_response.replaceAll("None", "\"None\"");
					}

					if (command_response != null) {
						String xxx = js.parse(command_response.toString()).toString();
						customResult = JSONToResult.convert(xxx);

					}

				}

				Set<String> sset = customResult.getIdOfAllDatasets();

				for (String s : sset) {
					Dataset ds1 = customResult.getDatasetById(s);
					for (Record rec : ds1.getAllRecords()) {

						for (Param p1 : rec.getAllParams()) {
							if (p1.getType().equalsIgnoreCase("int")) { //Change all int value to String and round int values .
								p1.setType("String");
								String val = p1.getValue() + "";
								p1.setValue(Math.round(Double.parseDouble(val)) + "");
							}

						}
					}

					if (s.equalsIgnoreCase("Customers")) { // Sort Customer collection by name
						List<Record> sortedCustomerList = new ArrayList<Record>(
								customResult.getDatasetById("Customers").getAllRecords());
						if (sortedCustomerList != null) {
							Collections.sort(sortedCustomerList, new CustomerOrder());
							Dataset sortedCustomerDS = new Dataset("Customers");
							sortedCustomerDS.addAllRecords(sortedCustomerList);

							result.addDataset(sortedCustomerDS);
						}

					} else {

						result.addDataset(customResult.getDatasetById(s));
					}

				}
				result.addParam(new Param("query", query));

			}
			pool.close();
		}
		result.addParam(new Param("opstatus", "0", "int"));
		result.addParam(new Param("httpStatusCode", "200", "int"));
		return false;

	}
}
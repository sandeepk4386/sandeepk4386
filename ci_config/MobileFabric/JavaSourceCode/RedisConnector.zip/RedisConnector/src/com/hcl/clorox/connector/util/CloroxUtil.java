package com.hcl.clorox.connector.util;

import com.konylabs.middleware.api.ConfigurableParametersHelper;
import com.konylabs.middleware.api.ServicesManager;
import com.konylabs.middleware.api.ServicesManagerHelper;
import com.konylabs.middleware.exceptions.MiddlewareException;

public class CloroxUtil {

	public static String getServerConfigurableParameter(String key) {
		String value = "";
		ServicesManager sm = null;
		try {
			sm = ServicesManagerHelper.getServicesManager();
			ConfigurableParametersHelper paramHelper = sm.getConfigurableParametersHelper();
			value = paramHelper.getServerProperty(key);
		} catch (MiddlewareException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return value;
	}

	public static int getServerConfigurableNumericParameter(String key) {
		int int_value = 0;
		ServicesManager sm = null;
		try {
			sm = ServicesManagerHelper.getServicesManager();
			ConfigurableParametersHelper paramHelper = sm.getConfigurableParametersHelper();
			String value = paramHelper.getServerProperty(key);
			int_value = Integer.parseInt(value);

		} catch (MiddlewareException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return int_value;
	}
	
}

package com.hcl.clorox;

import java.util.Iterator;

import com.konylabs.middleware.api.ConfigurableParametersHelper;
import com.konylabs.middleware.api.ServicesManager;
import com.konylabs.middleware.common.JavaService2;
import com.konylabs.middleware.controller.DataControllerRequest;
import com.konylabs.middleware.controller.DataControllerResponse;
import com.konylabs.middleware.dataobject.Param;
import com.konylabs.middleware.dataobject.Record;
import com.konylabs.middleware.dataobject.Result;

public class FetchAppUpgradeData implements JavaService2 {
	public Object invoke(String serviceId, Object[] inputs, DataControllerRequest request,
			DataControllerResponse response) throws Exception {
		Result result = new Result();
		ServicesManager sm = request.getServicesManager();
		ConfigurableParametersHelper paramHelper = sm.getConfigurableParametersHelper();
		Iterator itr = paramHelper.getAllClientAppProperties().keySet().iterator();
		String rcId = "UpgradeInfo";
		Record rc = new Record();
		rc.setId(rcId);
		while (itr.hasNext()) {
			String paramName = (String) itr.next();
			rc.addParam(new Param(paramName, paramHelper.getClientAppProperty(paramName)));
			result.addRecord(rc);
		}
		return result;
	}

}
